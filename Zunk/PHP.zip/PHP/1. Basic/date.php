<!DOCTYPE html>
<html>
<body>

<?php
echo "Date  ";
echo date("d m y") . "<br />";
?>

</body>
</html>
