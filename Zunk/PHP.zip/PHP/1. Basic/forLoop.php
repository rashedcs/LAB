<!DOCTYPE html>
<html>
<body>

<?php
for($i=0; $i<=10; $i++)
{
  echo $i. "</br>";
}
?> 

</body>
</html>
