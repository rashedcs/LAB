<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>
    
<?php
    
$color = "red";
echo "My car is " . $color . "\n"; 
echo "I Love PHP\n";

/*
We can also use  "<br>" as a new line.
*/
?>

</body>
</html>
